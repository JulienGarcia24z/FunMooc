source("library.R")
source("code/file.R")


url_path = paste("mongodb://",user,":",mdp,"@127.0.0.1:27017/admin",sep = "")
mongo_db <- mongo(collection = "dataForum",db = "bdd_grp2",url = url_path,verbose = TRUE)


value = mongo_db$aggregate('[
    {
        "$group": {
            "_id": "$content.username", 
            "number": {
                "$addToSet": "$content.username"
            }
        }
    }, {
        "$count": "utilisateurs"
    }
]')







