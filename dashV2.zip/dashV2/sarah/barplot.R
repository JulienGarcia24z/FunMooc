source("library.R")

myco <- mongo("dataForum", url = "mongodb://scantonnet:d}#2uyKYL}4e@127.0.0.1:27017/bdd_grp2?authSource=admin")
# Execution d'un find()
myco$count()

df <- myco$aggregate('[{"$group": {"_id":"$content.thread_type","N": {"$sum": 1 } } }]')

colnames(df) <- c("typePost","qty")
x <- colSums(df[-1])

df <- mutate(df, pourcentage = qty*100/x)

sarah = ggplot(df) +
  aes(x = `typePost`) +
  geom_bar(aes(weight=pourcentage)) +
  scale_fill_manual(values=wes_palette(name="IsleofDogs2"))+
  theme(legend.position="none")+
  ggtitle("Répartition des types de post")+
  xlab("Type de post") +
  ylab("Pourcentage")