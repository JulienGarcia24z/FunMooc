source("library.R")
source("code/graphjulien.R")
source("Eric/GraphePageGarde.R")
source("sarah/barplot.R")
# Indices
source("indices/nbUser.R")

# DASHBOARD
dash = dashboardPage(
  skin = "purple",
  dashboardHeader(title = "Python pour tous"),
  dashboardSidebar(),
  dashboardBody(
   
  # InfoBox ------------------------------------------------
    fluidRow(
      infoBox("Nombre d'utilisateur :", value, icon = icon("comment"), fill = TRUE, color = "green"),
      infoBox("??????????????", 10 * 4, icon = icon("users"), fill = TRUE, color = "orange"),
      infoBox("??????????????", 10 * 3, icon = icon("envelope-o"), fill = TRUE, color = "fuchsia"),
      ),
    
    fluidRow(
 #  Graphique ------------------------------------------------
    box(title="Titre1", plotOutput("plot1")),
    box(title="Titre2", plotOutput("plot2")),
    box(title="Titre3", plotOutput("plot3")),
    box(title="Titre4", plotOutput("plot4"))
    ),
  # CSS ------------------------------------------------
  tags$head(
     tags$link(rel = "stylesheet", type = "text/css", href = "custom.css")
    )  
  
  )
  
)

# SERVER
server = function(input, output) {
  output$plot1 = renderPlot(graph2)
  output$plot2 = renderPlot(barplot(df1gg$`length(Pseudonyme)`,names.arg = df1gg$Nombre_de_message_posté , xlab = "Nombre de messages postés" , ylab = "nombre de personnes", axis.lty = 15, col = "blue"))
  output$plot3 = renderPlot(sarah)
}
# Run dashboard 
shinyApp(dash, server)