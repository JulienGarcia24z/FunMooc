source("code/file.R")
source("library.R")
# Scripte R contenant les identifiants à placer avec le scripte d'éxecution

# Connexion dans la bdd de mongodb voulu après avoir effectuer la connexion ssh avec le port 27017 et la connexion à mongodb depuis le terminal
url_path = paste("mongodb://",user,":",mdp,"@127.0.0.1:27017/admin",sep = "")
mongo_db <- mongo(collection = "dataForum",db = "bdd_grp2",url = url_path,verbose = TRUE)

# Graphe représentant le nombre de personne ayant mis des comantaires en fonction du nombre de commentaires postés 
df1er = data.frame(mongo_db$aggregate('[{"$unwind": {"path": "$content.endorsed_responses"}}, {"$group": {"_id": "$content.endorsed_responses.username","Compteur": {"$sum": 1}}}]'))
df1ner = data.frame(mongo_db$aggregate('[{"$unwind": {"path": "$content.non_endorsed_responses"}}, {"$group": {"_id": "$content.non_endorsed_responses.username","Compteur": {"$sum": 1}}}]'))
df1c = data.frame(mongo_db$aggregate('[{"$unwind": {"path": "$content.children"}}, {"$group": {"_id": "$content.children.username","Compteur": {"$sum": 1}}}]'))
df1 = bind_rows (df1er,df1ner,df1c)
df1g = df1%>%group_by(X_id)%>%summarise(Nombre_de_message_posté = sum(Compteur))%>%arrange(desc(Nombre_de_message_posté))%>%rename( Pseudonyme=X_id )
df1gg = df1g%>%group_by(Nombre_de_message_posté)%>%count (length(Pseudonyme))
df1gg = select(df1gg,1:2)
barplot(df1gg$`length(Pseudonyme)`,names.arg = df1gg$Nombre_de_message_posté , xlab = "Nombre de messages postés" , ylab = "nombre de personnes", axis.lty = 15, col = "blue")
title("  Nombre de personnes par nombre total de message posté")
axis(2,at=seq(0,200,25))
